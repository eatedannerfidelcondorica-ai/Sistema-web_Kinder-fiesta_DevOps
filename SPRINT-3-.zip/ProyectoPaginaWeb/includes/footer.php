<?php
// includes/footer.php
?>
    <script>
        function mostrarReseñas(idSalon, nombreSalon) {
            document.getElementById('tituloReseñas').textContent = nombreSalon;
            document.getElementById('contenidoReseñas').innerHTML = '<p>Cargando reseñas...</p>';
            document.getElementById('modalReseñas').style.display = 'block';
            
            fetch('ajax/cargar_reseñas.php?id=' + idSalon)
                .then(response => response.text())
                .then(data => {
                    document.getElementById('contenidoReseñas').innerHTML = data;
                })
                .catch(error => {
                    document.getElementById('contenidoReseñas').innerHTML = '<p class="mensaje mensaje-error">Error al cargar las reseñas.</p>';
                });
        }

        function cerrarModal() {
            document.getElementById('modalReseñas').style.display = 'none';
        }

        function enviarReseña(event, idSalon) {
            event.preventDefault();
            const form = event.target;
            const formData = new FormData(form);
            
            fetch('procesos/guardar_reseña.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('¡Reseña enviada con éxito!');
                    mostrarReseñas(idSalon, form.dataset.nombre);
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                alert('Error al enviar la reseña.');
            });
        }

        window.onclick = function(event) {
            const modal = document.getElementById('modalReseñas');
            if (event.target === modal) {
                cerrarModal();
            }
        }
    </script>
</body>
</html>