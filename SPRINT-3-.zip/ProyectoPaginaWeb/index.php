<?php
require_once __DIR__ . '/conexion.php';
$db = new conexion();
$pdo = $db->getConnection();

$stmt = $pdo->query("SELECT * FROM salon");
$salones = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include 'includes/header.php'; ?>

<section class="inicio" id="inicio">
    <div class="image">
        <img src="img/logo.png" alt="KINDERfiesta" onerror="this.src='https://placehold.co/400x180/25d1b2/0c443a?text=LOGO'">
    </div>
</section>

<section class="salones" id="salones">
    <h2 class="titulo-salones">Salones de Kinder Fiesta</h2>
    <div class="salones-container">
        <?php foreach ($salones as $salon): ?>
            <?php
            $stmtCalif = $pdo->prepare("SELECT AVG(estrellas) as promedio, COUNT(*) as total FROM calificacion WHERE id_salon = ?");
            $stmtCalif->execute([$salon['id_salon']]);
            $califInfo = $stmtCalif->fetch(PDO::FETCH_ASSOC);
            $promedio = $califInfo['promedio'] ? round($califInfo['promedio'], 1) : 0;
            $totalReseñas = $califInfo['total'];

            $urlFoto = 'img/salon' . $salon['id_salon'] . '.jpg';

            $estrellasHTML = '';
            for ($i = 1; $i <= 5; $i++) {
                if ($i <= $promedio) $estrellasHTML .= '<i class="fas fa-star"></i>';
                elseif ($i - 0.5 <= $promedio) $estrellasHTML .= '<i class="fas fa-star-half-alt"></i>';
                else $estrellasHTML .= '<i class="far fa-star"></i>';
            }
            ?>
            <div class="salon-card">
                <img src="<?php echo htmlspecialchars($urlFoto); ?>" 
                     alt="<?php echo htmlspecialchars($salon['nombre']); ?>" 
                     onerror="this.src='https://placehold.co/280x180/25d1b2/0c443a?text=<?php echo urlencode($salon['nombre']); ?>'">
                <h3><?php echo htmlspecialchars($salon['nombre']); ?></h3>
                <p>📞 <?php echo htmlspecialchars($salon['telefono']); ?></p>
                <p> <?php echo htmlspecialchars('DESCRIPCION:'); ?></p>
                <p> <?php echo htmlspecialchars($salon['descripcion']); ?></p>
                <p>📍 <?php echo htmlspecialchars(substr($salon['direccion'],0,30)) . (strlen($salon['direccion'])>30?'...':''); ?></p>
                <div class="rating">
                    <div class="promedio-estrellas"><?php echo $estrellasHTML; ?></div>
                    <div class="promedio-calificacion"><?php echo $promedio; ?>/5 (<?php echo $totalReseñas; ?> reseñas)</div>
                </div>
                <a href="https://www.google.com/maps?q=<?php echo $salon['latitud']; ?>,<?php echo $salon['longitud']; ?>" target="_blank" class="btn-ubicacion">Ubicación</a>
                <button class="btn-resenas" onclick="mostrarResenas(<?php echo $salon['id_salon']; ?>)">Ver reseñas</button>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<div id="modalResenas" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalResenas')">×</span>
        <div id="contenidoResenas"></div>
    </div>
</div>

<div id="modalLogin" class="modal">
    <div class="modal-content">
        <span class="close" onclick="cerrarModal('modalLogin')">×</span>
        <h3 style="color: #0c443a; margin-bottom: 20px;">Iniciar Sesión</h3>
        <form id="loginForm" onsubmit="iniciarSesion(event)">
            <div class="form-resena">
                <input type="text" name="usuario" placeholder="Usuario" required style="margin-bottom: 15px;">
                <input type="password" name="password" placeholder="Contraseña" required style="margin-bottom: 20px;">
                <button type="submit" style="width: 100%;">Acceder</button>
            </div>
        </form>
        <p id="loginMessage" style="text-align: center; margin-top: 15px; color: red;"></p>
    </div>
</div>


<script>
// La función ahora recibe el ID del modal a abrir para poder cerrarlo de manera específica.
// Aunque el código HTML de 'includes/header.php' no está incluido, si hay un botón para el login,
// se debería llamar a 'mostrarModal("modalLogin")'.

function mostrarResenas(idSalon){
    document.getElementById('modalResenas').style.display = 'block';
    document.getElementById('contenidoResenas').innerHTML = 'Cargando reseñas...';

    fetch('ajax/cargar_resenas.php?id=' + idSalon)
    .then(resp => resp.text())
    .then(html => {
        document.getElementById('contenidoResenas').innerHTML = html;
    })
    .catch(() => {
        document.getElementById('contenidoResenas').innerHTML = '<p class="mensaje mensaje-error">Error al cargar reseñas</p>';
    });
}
function mostrarLogin(){
    document.getElementById('modalLogin').style.display = 'block';
}
/**
 * Función genérica para mostrar un modal.
 * @param {string} idModal El ID del elemento modal (e.g., 'modalLogin', 'modalResenas').
 */
function mostrarModal(idModal) {
    const modal = document.getElementById(idModal);
    if (modal) {
        modal.style.display = 'block';
    }
}

/**
 * Función Corregida para cerrar cualquier modal.
 * Ahora recibe el ID del modal a cerrar.
 * @param {string} idModal El ID del elemento modal (e.g., 'modalLogin', 'modalResenas').
 */
function cerrarModal(idModal){
    const modal = document.getElementById(idModal);
    if (modal) {
        modal.style.display = 'none';
    }
}

// Función para enviar reseña con AJAX
function enviarResena(e, idSalon){
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);

    fetch('procesos/guardar_resena.php', {
        method: 'POST',
        body: formData
    })
    .then(resp => resp.json())
    .then(data => {
        alert(data.message);
        if(data.success){
            mostrarResenas(idSalon); // recargar reseñas
        }
    })
    .catch(() => alert('Error al enviar la reseña'));
}

/**
 * Función de ejemplo para manejar el inicio de sesión.
 */
// ... (código JavaScript previo)

/**
 * Función que maneja el inicio de sesión vía AJAX.
 */
function iniciarSesion(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const messageElement = document.getElementById('loginMessage');
    messageElement.textContent = 'Verificando...';

    fetch('procesos/login.php', { 
        method: 'POST',
        body: formData
    })
    .then(resp => resp.json())
    .then(data => {
        if (data.success) {
            messageElement.style.color = 'green';
            messageElement.textContent = data.message;
            
            // Redirección del administrador si la URL existe
            if (data.redirect) {
                setTimeout(() => {
                    window.location.href = data.redirect; // Redirigir a admin.php
                }, 500);
            } else {
                // Si no hay redirección específica (p.ej., usuario normal)
                setTimeout(() => {
                    cerrarModal('modalLogin');
                    window.location.reload(); 
                }, 1000);
            }

        } else {
            messageElement.style.color = 'red';
            messageElement.textContent = data.message || 'Error de autenticación.';
        }
    })
    .catch(() => {
        messageElement.style.color = 'red';
        messageElement.textContent = 'Error de conexión al servidor.';
    });
}
// ... (resto del código JavaScript)
</script>

<?php include 'includes/footer.php'; ?>